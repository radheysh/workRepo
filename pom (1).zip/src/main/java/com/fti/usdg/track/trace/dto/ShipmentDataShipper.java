/**
 * 
 */
package com.fti.usdg.track.trace.dto;

/**
 * @author Anup
 *
 */
public interface ShipmentDataShipper {

	public String getShipper();
}
