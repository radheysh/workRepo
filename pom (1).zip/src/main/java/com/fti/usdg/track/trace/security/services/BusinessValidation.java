/**
 * 
 */
package com.fti.usdg.track.trace.security.services;

import org.springframework.stereotype.Service;

import com.fti.usdg.track.trace.models.ShipmentDataEntity;

 

/**
 * @author bgadm
 *
 */
@Service
public class BusinessValidation {

	public String validateData(ShipmentDataEntity selectedRow) {
		// TODO Auto-generated method stub
		return null;
	}

}
